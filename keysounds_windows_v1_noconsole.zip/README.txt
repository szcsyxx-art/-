﻿Key Sounds  运行说明

1) 为获得按键监听权限，建议以管理员身份运行（右键 -> 以管理员身份运行）。
2) 运行：双击 run_admin.bat 或 run_normal.bat（前者会请求管理员权限）。
3) 配置文件将保存在用户目录：%USERPROFILE%\.keysounds（volume.txt, startup.txt）。
4) 日志文件：%USERPROFILE%\.keysounds\keysounds.log
5) 如果遇到声音或 pyo 报错，请先确认系统已安装 Microsoft Visual C++ 2015-2019 Redistributable。
