打包说明（使用 PyInstaller）

准备：
- 在项目虚拟环境中安装依赖：
  - pyinstaller（已安装）

一键打包命令（在项目根目录运行）：

Windows（生成 one-folder 可执行文件）：
E:/PythonProjects/effectspp/.venv/Scripts/pyinstaller.exe --onedir --add-data "keysounds;keysounds" --name keysounds keysounds/main.py

说明：
- 我们会将 `keysounds` 目录的数据（wav、默认配置）包含到可执行文件中。
- 打包后的 `dist/keysounds` 目录包含 `keysounds.exe` 可执行文件和 `_internal/keysounds` 中的资源。

运行时配置：
- 为了在打包后仍能保存用户设置（音量/启动界面偏好），程序会使用用户目录下的 `~/.keysounds`（Windows 上为 C:\Users\<你>\.keysounds）来写入 `volume.txt` 与 `startup.txt`。
- 如果没有用户配置文件，程序会使用打包时的默认文件（打包在资源中）。

常见问题与解决：
- 如果按键监听没有反应，可能需要以管理员权限运行程序（`keyboard` 模块需要全局钩子）。
- pyo 可能会提示缺少 WxPython，这影响的是 pyo 的可选 GUI 功能，不影响基本播放。
- 如果需要生成单文件（--onefile），请注意写入位置：程序已把用户配置放在用户目录，避免写入只读的临时目录。

调试建议：
- 先用不带 `--noconsole` 的方式打包并运行，这样可以看到日志与错误信息，便于排错。