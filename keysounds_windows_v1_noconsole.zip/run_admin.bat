@echo off
powershell -Command "Start-Process -FilePath '%~dp0keysounds.exe' -WorkingDirectory '%~dp0' -Verb RunAs"
