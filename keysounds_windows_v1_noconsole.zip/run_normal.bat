@echo off
start "" "%~dp0keysounds.exe"
