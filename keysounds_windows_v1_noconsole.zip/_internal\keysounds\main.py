import keyboard
import customtkinter as ctk
import pyo
import sys
from pathlib import Path


# helper to get resource path (works when frozen by PyInstaller)
def resource_path(relative):
    if getattr(sys, "frozen", False):
        base = Path(sys._MEIPASS)
    else:
        base = Path(__file__).resolve().parent
    candidate = base / relative
    if candidate.exists():
        return candidate
    # PyInstaller may place added-data under a subfolder (e.g., 'keysounds') inside _MEIPASS
    candidate2 = base / 'keysounds' / relative
    if candidate2.exists():
        return candidate2
    return candidate  # fallback

# user-writable config directory (keeps settings outside the bundled app)
CONFIG_DIR = Path.home() / ".keysounds"
CONFIG_DIR.mkdir(exist_ok=True)

# setup file logging so errors are captured when no console is present
LOGFILE = CONFIG_DIR / "keysounds.log"
import logging
logging.basicConfig(filename=str(LOGFILE), level=logging.INFO, format='%(asctime)s %(levelname)s: %(message)s')

packaged_volume = resource_path("volume.txt")
packaged_startup = resource_path("startup.txt")

VOLUME_FILE = CONFIG_DIR / "volume.txt"
STARTUP_FILE = CONFIG_DIR / "startup.txt"

# load volume (user config > packaged default)
if VOLUME_FILE.exists():
    VOLUME = float(VOLUME_FILE.read_text().strip())
else:
    VOLUME = float(packaged_volume.read_text().strip())

# load startup preference (user config > packaged default)
if STARTUP_FILE.exists():
    SHOW_STARTUP = STARTUP_FILE.read_text().strip() == "True"
else:
    SHOW_STARTUP = packaged_startup.read_text().strip() == "True"

# 启动pyo服务器
server = pyo.Server(buffersize=64).boot()
server.start()
KEY_PRESS_SOUND = pyo.SfPlayer(str(resource_path("key_press_sound.wav")), loop=False, speed=1, mul=VOLUME)
KEY_RELEASE_SOUND = pyo.SfPlayer(str(resource_path("key_release_sound.wav")), loop=False, speed=1, mul=VOLUME)

class KeyListener:
    def __init__(self):
        self.pressed_keys = []
        global VOLUME
        global KEY_PRESS_SOUND, KEY_RELEASE_SOUND
        global SHOW_STARTUP
        if SHOW_STARTUP:
            self.show_start_window()

        while True:
            event = keyboard.read_event()
            if event.event_type == keyboard.KEY_DOWN and event.name not in self.pressed_keys:
                self.pressed_keys.append(event.name)
                logging.info(f"Key pressed: {event.name}")
                KEY_PRESS_SOUND.out()
            elif event.event_type == keyboard.KEY_UP:
                if event.name in self.pressed_keys:
                    self.pressed_keys.remove(event.name)
                logging.info(f"Key released: {event.name}")
                KEY_RELEASE_SOUND.out()
            if keyboard.is_pressed('ctrl+alt+k'):
                self.open_settings_window()

    def open_settings_window(self):
        settings_win = settingsWindow()
        settings_win.mainloop()

    def show_start_window(self):
        start_win = startWindow()
        start_win.mainloop()


class settingsWindow(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("settings")
        self.geometry("400x300")

        self.label = ctk.CTkLabel(self, text="Settings Window", font=ctk.CTkFont(size=20, weight="bold"))
        self.label.pack(pady=10)

        self.volume_bar = ctk.CTkSlider(self, from_=0, to=1, orientation="horizontal", command=self.update_volume)
        self.volume_bar.set(VOLUME)
        self.volume_bar.pack(pady=20)
        self.label_volume = ctk.CTkLabel(self, text=f"Volume:{int(self.volume_bar.get() * 100)}%", font=ctk.CTkFont(size=16))
        self.label_volume.pack(pady=10)
        self.save_button = ctk.CTkButton(self, text="Save Settings", command=self.save_settings)
        self.save_button.pack(pady=20)
        self.leave_button = ctk.CTkButton(self, text="Leave Key Sounds", command=lambda: sys.exit(0), fg_color="red")
        self.leave_button.pack(pady=10)
        
    def update_volume(self, value):
        global VOLUME
        VOLUME = float(value)
        self.label_volume.configure(text=f"Volume:{int(VOLUME * 100)}%")
    
    def save_settings(self):
        global VOLUME
        global KEY_PRESS_SOUND, KEY_RELEASE_SOUND
        
        VOLUME_FILE.write_text(str(VOLUME))
        VOLUME = float(VOLUME_FILE.read_text().strip())
        KEY_PRESS_SOUND.setMul(VOLUME)
        KEY_RELEASE_SOUND.setMul(VOLUME)
        self.destroy()


class startWindow(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Key Sounds")
        self.geometry("600x400")

        self.label = ctk.CTkLabel(self, text="Welcome to Key Sounds", font=ctk.CTkFont(size=20, weight="bold"))
        self.label.pack(pady=20)

        self.instructions = ctk.CTkLabel(self, text="Press Ctrl+Alt+K to open settings; \n Close this window to run the program; \n If you want to stop the program, go to the settings window.", font=ctk.CTkFont(size=18))
        self.instructions.pack(pady=10)

        self.button = ctk.CTkCheckBox(self, text="Don't show this window on startup", command=self.toggle_startup)
        self.button.pack(pady=10)

        self.close_button = ctk.CTkButton(self, text="OK", command=self.destroy)
        self.close_button.pack(pady=20)

    def toggle_startup(self):
        if self.button.get() == 1:
            STARTUP_FILE.write_text("False")
        else:
            STARTUP_FILE.write_text("True")

if __name__ == "__main__":
    try:
        logging.info("Starting KeyListener")
        listener = KeyListener()
    except Exception as e:
        logging.exception("Unhandled exception in main: %s", e)
        # ensure crash is recorded in log file before exiting
        sys.exit(1)

